# DetailList-RecyclerView
17030013
Praktikum MC pertemuan ke 8
